-- Dates ecrites en Français
SET lc_time_names = 'fr_FR';

-- requete 1
SELECT Article.id AS id_article,DATE_FORMAT(date_publication,'%d/%m/%Y') AS date_publication, utilisateur.pseudo, titre, resume, 
	COUNT(*) AS nbr_commentaires
FROM Article
INNER JOIN Utilisateur ON auteur_id = Utilisateur.id
INNER JOIN Commentaire ON Article.id = Commentaire.id
GROUP BY Commentaire.article_id
ORDER BY date_publication DESC;

-- requete 2
SELECT Article.id AS id_article, DATE_FORMAT(date_publication,'%d %M ''%y') AS date_publication, utilisateur.pseudo, titre, 
	resume
FROM Article
INNER JOIN Utilisateur ON auteur_id = Utilisateur.id
WHERE Utilisateur.id = 2
ORDER BY date_publication DESC;

-- requete 3
SELECT Article.id AS id_article,DATE_FORMAT(date_publication,'%d/%m/%Y - %H:%i') AS date_publication, utilisateur.pseudo, titre, 
	resume
FROM Article
INNER JOIN Utilisateur ON auteur_id = Utilisateur.id
LEFT JOIN Categorie_article ON Article.id = Categorie_article.article_id
-- LEFT JOIN car il est possible que l'id d'un article ne soit pas renseigné avec une catégorie dans la table Categorie_article
-- bien qu'ici categorie_id = 3, cela permettrait d'effectuer une recherche sur tout les articles y compris avec 
	-- categorie_id = NULL lors d'un LEFT JOIN
WHERE categorie_id = 3
ORDER BY date_publication DESC;

-- requete 4
SELECT Article.id AS id_article, DATE_FORMAT(date_publication,'%d %M %Y à %H heures %i"') AS date_publication, 
	titre, contenu, pseudo AS pseudo_auteur, GROUP_CONCAT(Categorie.nom) AS Nom_categories
FROM Article
INNER JOIN Utilisateur ON auteur_id = Utilisateur.id
LEFT JOIN Categorie_article ON Article.id = Categorie_article.article_id
LEFT JOIN Categorie ON Categorie.id = categorie_id
WHERE Article.id = 4
GROUP BY Categorie_article.article_id;

