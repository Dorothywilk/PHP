DROP DATABASE IF EXISTS p2p_blog;
CREATE DATABASE p2p_blog CHARACTER SET 'utf8';

USE p2p_blog;




CREATE TABLE Categorie (

	id INT UNSIGNED AUTO_INCREMENT,

	nom VARCHAR(150) NOT NULL UNIQUE,

	description TEXT NOT NULL,

	PRIMARY KEY(id))
ENGINE=INNODB;




CREATE TABLE Utilisateur (
	id INT UNSIGNED AUTO_INCREMENT,
	pseudo VARCHAR(16) NOT NULL UNIQUE,
	email VARCHAR(64) NOT NULL UNIQUE,
	mot_de_passe VARCHAR(16) NOT NULL,
	PRIMARY KEY(id)
	)
ENGINE=INNODB;




CREATE TABLE Article (
	id INT UNSIGNED AUTO_INCREMENT,
	titre VARCHAR(100) NOT NULL UNIQUE,
	date_creation DATETIME NOT NULL,
	auteur_id INT UNSIGNED NOT NULL,
	texte TEXT NOT NULL,
	resume VARCHAR(300),
	PRIMARY KEY(id),
	INDEX ind_date_creation (date_creation),
	CONSTRAINT fk_auteur_id
		FOREIGN KEY (auteur_id)
		REFERENCES Utilisateur(id)
		ON DELETE CASCADE
	)
ENGINE=INNODB;




CREATE TABLE Categorie_article (

	categorie_id INT UNSIGNED,

	article_id INT UNSIGNED,

	PRIMARY KEY (categorie_id, article_id),
	CONSTRAINT fk_categorie_id
		FOREIGN KEY (categorie_id)
		REFERENCES Categorie(id)
		ON DELETE CASCADE,
	CONSTRAINT fk_article_id
		FOREIGN KEY (article_id)
		REFERENCES Article(id)
		ON DELETE CASCADE
	)
ENGINE=INNODB;




CREATE TABLE Commentaires (
	id INT UNSIGNED AUTO_InCREMENT,
	id_article INT UNSIGNED NOT NULL,
	id_utilisateur INT UNSIGNED,
	date_heure DATETIME NOT NULL,
	texte TEXT NOT NULL,
	PRIMARY KEY(id),
	INDEX ind_article_date (id_article, date_heure),
	CONSTRAINT fk_id_article
		FOREIGN KEY (id_article)
		REFERENCES Article(id)
		ON DELETE CASCADE,
	CONSTRAINT fk_id_utilisateur
		FOREIGN KEY (id_utilisateur)
		REFERENCES Utilisateur(id)
		ON DELETE CASCADE
	)
ENGINE=INNODB;


	
	