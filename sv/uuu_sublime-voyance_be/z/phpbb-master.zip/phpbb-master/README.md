French Language Package 3.0
===========================

French Language Package compatible with the phpBB® "Rhea" 3.2 Forum Software.

Version
-------

[![Build Status](https://travis-ci.org/maelsoucaze/phpbb.svg?branch=master)](https://travis-ci.org/maelsoucaze/phpbb)

- 3.0.0-dev (Build 5)
- Released on May 4, 2015
- Compatible with [phpBB 3.2.0-a1-dev (Build 642)](https://bamboo.phpbb.com/browse/PHPBB3-RHEA)

License
-------
The French Language Package is released under the [GNU General Public License 2.0] (http://opensource.org/licenses/GPL-2.0).