<?php
// Version: 2.1 Beta 1; Settings

global $settings;

$txt['theme_thumbnail_href'] = $settings['images_url'] . '/thumbnail.png';
$txt['theme_description'] = 'The default theme from Simple Machines.<br><br>Author: The Simple Machines Team';

?>