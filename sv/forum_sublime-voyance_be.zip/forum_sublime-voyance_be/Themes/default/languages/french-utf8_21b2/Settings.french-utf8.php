<?php
// Version: 2.1 Beta 2; Settings

global $settings;

$txt['theme_thumbnail_href'] = $settings['images_url'] . '/thumbnail.gif';
$txt['theme_description'] = 'Le thème par défaut de Simple Machines.<br><br>Auteur : l\'Équipe Simple Machines';

?>