<?php
/**
 * Created by C7.
 * User: Li
 * Date: 15/08/2015
 * Time: 13:12
 */
// C:\xampp\htdocs\w\wwwconcr\public_html\forum_concrete5_fr
$forum_version = 'SMF 2.1b2';

include( ( $_SERVER['SERVER_NAME'] != 'fsv' ) ? 'Settings.php' : 'settings/Settings_local.php' );
//include('settings/Settings_reel.php');
