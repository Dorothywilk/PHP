[b]Description[/b]
Allows anyone (including guests) to subscribe to an automatically generated weekly. fortnightly or monthly email newsletter.  Guests need to enter their email address, registered members don't.  The subscription options shows above the board index and (optionally) during forum registration.

The Newsletter can optionally contain forum stats, the latest news item, recent topics list, upcoming events from the calendar, video links (included in posts), and recent picture from SMF Gallery (if installed) - the newsletter email always includes an unsubscribe link.

Features:
[list]
[li]Newsletter can be subscribed to during initial forum registration or at any time[/li]
[li]Newsletter frequency can be selected by the user when subscribing (weekly, fortnightly or monthly)[/li]
[li]Frequency timer starts from when the user subscribes (to reduce server email load).[/li]
[li]Subscriber can unsubscribe on the forum OR by clicking an "unsubscribe" link in the Newsletter.[/li]
[li]Newsletter sub/unsubscribe options show above OR below forum list.[/li]
[li]Newsletter is HTML formatted (includes plain text version) using forum name and logo image (styling can be edited).[/li]
[li]Portal PHP block code included (to allow newletter subscription options to appear on any portal page (using a custom portal PHP block)[/li]
[/list]

Admin Settings:
[list]
[li]Allow guest to subscribe to the newsletter.[/li]
[li]Use guest permissions when selecting topics, videos and pictures to include.[/li]
[li]Choose position of Subscribe/Unsubscribe buttons (top or bottom of forum listing)[/li]
[li]Chose whether subscribtion option is shown during forum registration[/li]
[li]Number of recent topic titles/links to include in the newsletter (set to 0 to exclude topics from the newsletter)[/li]
[li]Select which boards to exclude when selecting topics[/li]
[li]Number of recent videos to include (set to 0 to exclude videos from the newsletter)[/li]
[li]Select which boards to exclude videos from[/li]
[li]Include SMF Gallery pictures[/li]
[li]Gallery categories to ignore[/li]
[li]Include basic forum stats[/li]
[li]Include the latest news item (the SMF newsfader doesn't have to be enabled)[/li]
[li]Include basic forum stats[/li]
[li]Include calendar events[/li]
[li]Manual subscribtion removal by email address - allows deletion of invalid or bouncing emails[/li]
[li]Newletter CSS styling can be edited in the SMF Language Editor[/li]
[li]Newletter can be previewed before activating.[/li]
[/list]

Note that unless you have selected guest permissions or exclude some board(s) then the titles of (and links to) new topics that appear in ALL boards will be included in the newsletter even if the recipient does not have permission to read the topic post itself.  This can be used as a way to encourage forum or group membership by showing topic titles but not allowing access to the content.

To change the CSS styling of the newsletter:
[i]Admin->Configuration->Languages->Edit Languages->(whatever your langueg is called)->edit Languages Entries -> select "Modifications"[/i]
... find and edit the CSS string "newsltr_email_style"


Requirements:
PHP version 5.2 or higher
SMF version 2.0 or higher

[b]Note[/b]: 
On some web hosts you may need to disable compression in SMF (if the newletter preview shows a blank page):
Admin->Configuration->Server Settings->General and clear enable compressed output option

[b]Adding Newsletter Subscription to a Portal page[/b]
You can add the newsletter subscription options on any portal page (if it supports custom PHP code blocks - EzPortal, SimplePortal, etc.)  After installing this mod, create a new custom PHP block in your portal (see portal instaructions) and paste the code from the file [b]portal_block.php[/b], included in this zip package into the new block.

[i]Updates:[/i]
[size=8pt]v1.25
added subscribe on register feature
v1.23
fixed portal_block.php syntax error
added more robust check for SMF Gallery
v1.22
fixed bug in video inclusion code (shows in error log)
added sample portal PHP block code
v1.21
fixed SMF_Gallery detection bug in adminsettings 
v1.20
Cleaned up HTML format imporving email client compatibility
Newsletter can include SMF Gallery pictures and YouTube videos (from posts)
v1.14
Now works properly on forums with unsupported languages (reverts to english)
v1.13
moved newsletter CSS style to languages - can now be edited by an admin
....
[/size]

License:
	Copyright 2012/2013 John Robertson
	Released under the GNU/GPL license

    This is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This software is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
