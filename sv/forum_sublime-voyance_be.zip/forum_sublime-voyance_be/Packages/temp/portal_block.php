<?php
	global $modSettings, $txt, $scripturl, $context;
	
	// make sure newletter is installed and enabled
	if (!empty($modSettings['newsltr_news']) OR !empty($modSettings['newsltr_events']) OR !empty($modSettings['newsltr_topic_count']))
	{
		$context['user']['newsltr'] = array('next_ltr_date'=>'', 'period'=>'', 'email'=>'',);
		if (!$context['user']['is_guest'])
		{
			global $smcFunc;
			$result = $smcFunc['db_query']('', '
				SELECT email, next_ltr_date, period
					FROM smf_hcb_newsletter
				WHERE email = \'' . $context['user']['email'] . '\'
					LIMIT 1'
			);

			if ($row = $smcFunc['db_fetch_assoc']($result))
				$context['user']['newsltr'] = $row;
			$smcFunc['db_free_result']($result);
		}
	
		echo '
	<div class="smalltext">
		<form action="',$scripturl,'?action=NewsSubscribe" method="post" accept-charset="',$context['character_set'],'" name="newsSubscriber">
			<input type="hidden" name="sc" value="', $context['session_id'], '" />
			<input type="hidden" name="lastaction" value="forum" />' . $context['forum_name'] . ' ' . $txt['newsubscribe_mod_title'];
		
		if ($context['user']['is_guest'])
			echo $txt['newsubscribe_mod_email'] . '<input type="text" clasa="input_text" maxlength="255" size="25" value="' . $context['user']['newsltr']['email'] . '" name="email" />';
		else
			echo '
				<input type="hidden" name="email" value="', $context['user']['email'], '" />';
		if ($context['user']['is_guest'] OR empty($context['user']['newsltr']['email']))
			echo '
			<input type="submit" class="button_submit" name="subscribe" value="' . $txt['newsubscribe_mod_subscribe'] .'"/>
			<br /><Input type="radio" name ="period" value="7"' . (($context['user']['newsltr']['period'] == 7) ? ' checked' :'')  . '>' .
			$txt['newsubscribe_mod_week'] . '
			<br /><Input type="radio" name ="period" value="14"' . (($context['user']['newsltr']['period'] == 14) ? ' checked' :'')  . '>' .
			$txt['newsubscribe_mod_fort'] . '
			<br /><Input type="radio" name ="period" value="30"' . ((empty($context['user']['newsltr']['period']) OR $context['user']['newsltr']['period'] == 30) ? ' checked' : '')  . '>' . $txt['newsubscribe_mod_month'];
		if ($context['user']['is_guest'] OR !empty($context['user']['newsltr']['email']))
			echo ($context['user']['is_guest'] ? '<br />' : $txt['newsubscribe_mod_next'] . date(' j F', $context['user']['newsltr']['next_ltr_date'])) . '<input type="submit" class="button_submit" name="unsubscribe"  value="' . $txt['newsubscribe_mod_unsubscribe'] .'"/>';
	echo '
		</form>
	</div>';
	}
?>

