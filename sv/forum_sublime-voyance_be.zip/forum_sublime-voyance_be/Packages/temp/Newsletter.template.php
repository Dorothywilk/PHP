<?php
function template_main()
{
	global $txt, $scripturl, $context;
		
	echo '	
	<div class="linked_events">
		<div class="title_bar">
			<h3 class="titlebg headerpadding">', $txt['newsubscribe_mod_title'], '</h3>
		</div>
		<div class="windowbg">
			<span class="topslice"><span></span></span>
			<div><br />';
	if ($context['user']['newsltr']['error'] == 'delemail')
		echo '
				<form action="' . $scripturl . '?action=NewsSubscribe" method="post" accept-charset="' . $context['character_set'] . '" name="newsSubscribe">' . $txt['newsubscribe_mod_email'] . ' 
					<input type="hidden" name="sc" value="' . $context['session_id'] . '" />
					<input type="hidden" name="lastaction" value="' . $_REQUEST['lastaction'] . '" />
					<input type="text" clasa="input_text" maxlength="255" size="25" value="" name="email" />
					<input type="submit" class="button_submit" name="unsubscribe" value="' . $txt['newsubscribe_mod_unsubscribe'] .'" />
				</form>';
	else
		echo 
			$context['user']['newsltr']['error'] . (isset($context['user']['newsltr']['next_ltr_date']) ? $txt['newsubscribe_mod_next'] . date(' j F', $context['user']['newsltr']['next_ltr_date']): '') . '<br /><br />
				<a class="button_submit" style="padding:4px;" href="'. $scripturl . (isset($_REQUEST['lastaction']) ? '?action=' . $_REQUEST['lastaction'] : '') . '">'. $txt['newsubscribe_mod_done'] .'</a>';
		echo '
			</div>
			<span class="botslice"><span></span></span>
		</div>
	</div>';
}
?>