<?php
/* 
	Copyright 2012 John Robertson
	Released under the GNU/GPL license

	This file is part of the automatic newsletter mod for SMF2.

    This is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This software is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
*/

if (!defined('SMF'))
	die('Hacking attempt...');

// called from boardindex template 
// OR via an email unsubscribe link = ../index.php?action=NewsSubscribe;button=Unsubscribe;email=jon@somewhere.com
function Handler()
{
	global $txt, $context, $smcFunc, $scripturl, $sourcedir, $mbname, $modSettings, $settings;

	if (isset($_REQUEST['preview']))
	{
		require_once($sourcedir . '/Subs-Newsletter.php');
		get_news(); // show preview
	}
	else
	{
		if (isset($_REQUEST['period']))
			$_REQUEST['period'] = (int)$_REQUEST['period'];

		$email = isset($_REQUEST['email']) ? filter_var($_REQUEST['email'], FILTER_SANITIZE_EMAIL) : '';

		if (isset($_REQUEST['subscribe']) OR isset($_REQUEST['unsubscribe']) OR isset($_REQUEST['delemail']))
		{
			if (filter_var($email, FILTER_VALIDATE_EMAIL) == false)
				$context['user']['newsltr']['error'] =  (isset($_REQUEST['delemail']) ? 'delemail' : $txt['newsubscribe_mod_bademail']);
			else // email is valid
			{
				if (isset($_REQUEST['subscribe']))
				{
					checkSession(); // valid session before subscribe allowed!
					if (isset($_REQUEST['period']))
					{
						$context['user']['newsltr']['next_ltr_date'] = time() + (86400 * $_REQUEST['period']);
						$smcFunc['db_insert']('replace',
							'{db_prefix}hcb_newsletter',
							array('next_ltr_date' => 'int', 'email' => 'text', 'period' => 'int',),
							array($context['user']['newsltr']['next_ltr_date'], $email, $_REQUEST['period'],),
							array()
						);
						$context['user']['newsltr']['error'] = $txt['newsubscribe_mod_donesub'] . $context['forum_name'] . ' '. $txt['newsubscribe_mod_title'];
					}
				}
				elseif (isset($_REQUEST['unsubscribe']) OR isset($_REQUEST['delemail']))
				{
					$request = $smcFunc['db_query']('','
						DELETE FROM {db_prefix}hcb_newsletter
						WHERE email = {text:email}',
						array(
							'email' => $email,)
					);
					if ($smcFunc['db_affected_rows']() == 0)
						$context['user']['newsltr']['error'] = $email . ' - ' . $txt['newsubscribe_mod_noemail'];
					else
						$context['user']['newsltr']['error'] = $email . ' - ' . $txt['newsubscribe_mod_doneunsub'] . $context['forum_name'] . ' '. $txt['newsubscribe_mod_title'];
				}
				else
					redirectexit($scripturl . (isset($_REQUEST['lastaction']) ? '?action=' . $_REQUEST['lastaction'] : '')); // back to home page or wherever
			}
			loadTemplate('Newsletter');
			return; // show confirmation
		}
		redirectexit($scripturl . (isset($_REQUEST['lastaction']) ? '?action=' . $_REQUEST['lastaction'] : '')); // back to home page or wherever
	}
}
?>