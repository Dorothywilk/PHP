<?php
/* 
	Copyright 2012 John Robertson
	Released under the GNU/GPL license

	This file is part of the Global Post Limit mod for SMF2.

    This is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This software is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
*/

	if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
		require_once(dirname(__FILE__) . '/SSI.php');
	elseif (!defined('SMF'))
		die('<b>Error:</b> Cannot install - please verify you put this in the same place as SMF\'s index.php.');

	if (@version_compare(PHP_VERSION, '5.2','<'))
		fatal_error('<b>Error:</b> Unable to install - this mod requires PHP version 5.2 or higher (your server is running PHP ' . PHP_VERSION);

	// Load the SMF DB Functions
	db_extend('packages');

	$columns = array(
		array(
			'name' => 'next_ltr_date',
			'type' => 'int',
			'size' => 10,
			'unsigned' => true,
			'null' => false,
			'default' => 0,	
		),
		array(
			'name' => 'email',
			'type' => 'varchar',
			'size' => 255,
		),
		array(
			'name' => 'period',
			'type' => 'mediumint',
			'size' => 3,
			'unsigned' => true,
			'null' => false,
			'default' => 0,	
		),
	);

	$indexes = array(
		array(
			'type' => 'primary',
			'columns' => array('email'),
		),
		array(
			'name' => 'next_date',
			'columns' => array('next_ltr_date'),
		),
	);

	if ($smcFunc['db_create_table']('{db_prefix}hcb_newsletter', $columns, $indexes, array(), 'ignore') === false)
		die ('<b>Error:</b> Failed to insert new table.');

	// add scheduled task
	$smcFunc['db_query']('','
		REPLACE INTO {db_prefix}scheduled_tasks
			(id_task, next_time, time_offset, time_regularity, time_unit, disabled, task)
			VALUES (NULL, 0, 11520, 1, \'d\', 0, \'newsltr\')
  	');

	// add settings into SMF.
	// List settings here in the format: setting_key => default_value.  Escape any "s. (" => \")
	$mod_settings = array(
		'newsltr_stats' => '1',
		'newsltr_news' => '1',
		'newsltr_topic_count' => '20',
		'newsltr_allow_guests' => '1',
		'newsltr_use_perms' => '1',
		'newsltr_exclude_boards' => serialize(array(0)),
		'newsltr_events' => '1',
		'newsltr_position' => '0',
		'newsltr_picture_count' => '6',
		'newsltr_video_count' => '6',
		'newsltr_exclude_vboards' => serialize(array(0)),
		'newsltr_register_subscribe' => '1',
	);

	// only update settings if they don't exist already (from a previous install)
	$replaceArray = array();
	foreach ($mod_settings as $variable => $value)
	{
		if (isset($modSettings[$variable]) OR empty($value))
			continue;
		$replaceArray[] = array($variable, $value);
		$modSettings[$variable] = $value; // update variable in memory
	}

	if (!empty($replaceArray))
	{
		$smcFunc['db_insert']('replace','{db_prefix}settings',array('variable' => 'string-255', 'value' => 'string-65534'),$replaceArray,array('variable'));
		cache_put_data('modSettings', null, 90); // remove any cache entry
	}

?>