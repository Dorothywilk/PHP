<?php
function get_news()
{
	global $txt, $boarddir, $sourcedir, $smcFunc, $mbname, $scripturl, $modSettings, $settings, $boardurl, $context;

	// Get some news...
	if (!empty($modSettings['newsltr_news']))
	{
		$news_lines = explode("\n", str_replace("\r", '', trim(addslashes($modSettings['news']))));
		// Clean it up for presentation ;).
		$latest_news = parse_bbc(stripslashes(trim(end($news_lines))), true, 'newsltr');
	}

	if (!empty($modSettings['newsltr_picture_count']))
	{
		include ($sourcedir . '/Subs-Package.php');
		$installed = loadInstalledPackages(); // get list of installed packages
		foreach ($installed as $name)
		{
			if (stripos($name['name'], 'SMF Gallery') !== false)
			{
				if (empty($modSettings['gallery_thumb_height']))
					$modSettings['gallery_thumb_height'] = 78;
					
				if (empty($modSettings['gallery_thumb_width']))
					$modSettings['gallery_thumb_width'] = 120;

				$exclude_cats = (!empty($modSettings['newsltr_exclude_cats']) ? unserialize($modSettings['newsltr_exclude_cats']) : array());
				$query = (empty($exclude_cats) ? '1=1 ' : ' p.id_cat NOT IN (' . implode(', ', $exclude_cats) . ')');
				//Check if the gallery url has been set if not use the default
				if (empty($modSettings['gallery_url']))
					$modSettings['gallery_url'] = $boardurl . '/gallery/';
				
				$request = $smcFunc['db_query']('', '
					SELECT 
						p.id_picture, p.thumbfilename, p.title, p.filename, p.id_cat, p.description AS descr,
						c.title as cat_title
					FROM {db_prefix}gallery_pic as p 
						LEFT JOIN {db_prefix}gallery_cat AS c ON (p.ID_CAT = c.ID_CAT)  
					WHERE 
						p.approved = 1 
						AND {raw:query}
					ORDER BY p.ID_PICTURE DESC 
				
					LIMIT {int:limit}',
					array(
						'approved'=>1, 
						'query'=> $query,
						'limit'=> ($modSettings['newsltr_picture_count']>20 ? 20 : $modSettings['newsltr_picture_count']),
						)
						);
				
				while ($picture = $smcFunc['db_fetch_assoc']($request))
					$pictures[] = $picture;
				$smcFunc['db_free_result']($request);
				
				break;
			}
		}		
	}
	

	if (!empty($modSettings['newsltr_video_count']))
	{
		$exclude_boards = (!empty($modSettings['newsltr_exclude_vboards']) ? unserialize($modSettings['newsltr_exclude_vboards']) : array());
		if (!empty($modSettings['recycle_enable']) && $modSettings['recycle_board'] > 0)
			$exclude_boards[] = $modSettings['recycle_board']; // always exclude the recycle board
		$query = (empty($exclude_boards) ? '1=1 ' : ' t.id_board NOT IN (' . implode(', ', $exclude_boards) . ')');
		$query .= ($modSettings['newsltr_use_perms'] ? ' AND (-1 IN(b.member_groups)) ' : '' );
		$limit = ($modSettings['newsltr_video_count']>20 ? 20 : $modSettings['newsltr_video_count']);

		$request = $smcFunc['db_query']('', '
			SELECT
				subject, body
			FROM {db_prefix}messages AS m
				LEFT JOIN {db_prefix}boards AS b ON (m.id_board = b.id_board)
				LEFT JOIN {db_prefix}topics AS t ON (m.id_topic = t.id_topic)
			WHERE 
				t.approved = {int:approved}
				AND (
					m.body LIKE(\'%[url=http://www.youtube.com%\') 
					OR m.body LIKE(\'%[url=http://youtu.be%\') 
					OR m.body LIKE(\'%[url=http://www.youtu.be%\')
				)
				AND {raw:query}
			ORDER BY poster_time DESC
			LIMIT {int:limit}',
			array(
				'approved'=>1, 
				'query'=> $query,
				'limit'=> $limit,
				)
		);
			
		$vcount = 0;
		$vidIds = array();
		while (($row = $smcFunc['db_fetch_assoc']($request)) AND ($vcount < $limit))
		{
			preg_match_all('/\\[url=(.+)\\]/isU',$row['body'],$matches); // extract all URL = parts from the post body
			foreach ($matches[1] as $match)
			{
				if (!empty($match))
				{
					if (($ytquery = parse_url($match)) != NULL) // split url
					{
						if (in_array($ytquery['host'],array('www.youtube.com','youtube.com','www.youtu.be','youtu.be')))
						{
							if (isset($ytquery['query']))  // got a query version
								parse_str($ytquery['query'],$yt); // get any query string into array
							else // must be the short URL version
							{
								if (isset($ytquery['fragment']))
									$yt_arr = explode('/',$ytquery['fragment']);
								else
									$yt_arr = explode('/',$ytquery['path']);
								$yt['v'] = end($yt_arr); // assume it's the last paramter in the URL
							}
							if (isset($yt['v']) AND !in_array($yt['v'], $vidIds)) // got a unique video ID?
							{
								$vidIds[] = $yt['v']; // make sure we don't show same vid twice
								$videos[] = array(
									'subject' => $row['subject'],
									'yid' => $yt['v'],
									);
								$vcount++;
							}
						}
					}
				}
			}
		}
		
		$smcFunc['db_free_result']($request);

	}

	// get a list of latest topics 
	if (!empty($modSettings['newsltr_topic_count']))
	{
		$exclude_boards = (!empty($modSettings['newsltr_exclude_boards']) ? unserialize($modSettings['newsltr_exclude_boards']) : array());
		if (!empty($modSettings['recycle_enable']) && $modSettings['recycle_board'] > 0)
			$exclude_boards[] = $modSettings['recycle_board']; // always exclude the recycle board
		$query = (empty($exclude_boards) ? '1=1 ' : ' t.id_board NOT IN (' . implode(', ', $exclude_boards) . ')');
		$query .= ($modSettings['newsltr_use_perms'] ? ' AND (-1 IN(b.member_groups)) ' : '' );
			
		// Retrieve the latest posts
		$request = $smcFunc['db_query']('', '
			SELECT
				m.poster_time, m.subject, m.id_topic, m.icon,
				IFNULL(mem.real_name, m.poster_name) AS poster_name
			FROM {db_prefix}topics AS t
				LEFT JOIN {db_prefix}boards AS b ON (t.id_board = b.id_board)
				LEFT JOIN {db_prefix}messages AS m ON(t.id_last_msg = m.id_msg)
				LEFT JOIN {db_prefix}members AS mem ON (mem.ID_MEMBER = m.ID_MEMBER)
			WHERE 
				t.approved = {int:approved}
				AND {raw:query}
			ORDER BY m.poster_time DESC
			LIMIT {int:limit}',
			array(
				'approved'=>1, 
				'query'=> $query,
				'limit'=> ($modSettings['newsltr_topic_count']>50 ? 50 : $modSettings['newsltr_topic_count']),
				)
		);
			
		while ($row = $smcFunc['db_fetch_assoc']($request))
			$posts[] = $row;
		$smcFunc['db_free_result']($request);
	}

	// get upcoming events from today
	if (!empty($modSettings['cal_enabled']) AND !empty($modSettings['newsltr_events']))
	{
		require_once($sourcedir . '/Subs-Calendar.php'); 
		$low_date = strftime('%Y-%m-%d', forum_time(false) - 24 * 3600);
		$high_date = strftime('%Y-%m-%d', forum_time(false) + $modSettings['cal_days_for_index'] * 24 * 3600);
		$low_date_time = sscanf($low_date, '%04d-%02d-%02d');
		$low_date_time = mktime(0, 0, 0, $low_date_time[1], $low_date_time[2], $low_date_time[0]);
		$high_date_time = sscanf($high_date, '%04d-%02d-%02d');
		$high_date_time = mktime(0, 0, 0, $high_date_time[1], $high_date_time[2], $high_date_time[0]);

		// Find all the calendar info...
		$result = $smcFunc['db_query']('', '
			SELECT
				cal.id_event, cal.start_date, cal.end_date, cal.title, cal.id_topic, cal.id_board
			FROM {db_prefix}calendar AS cal
				LEFT JOIN {db_prefix}topics AS t ON (t.id_topic = cal.id_topic)
			WHERE cal.start_date <= {date:high_date}
				AND cal.end_date >= {date:low_date}
			ORDER BY cal.start_date
			',
			array(
				'high_date' => $high_date,
				'low_date' => $low_date,
			)
		);

		$lastevent_ids = array();
		$allevents = array();
		while ($row = $smcFunc['db_fetch_assoc']($result))
		{
			if (in_array($row['id_event'],$lastevent_ids)) // listed this one already?
				continue;

			$lastevent_ids[] = $row['id_event'];
			// Force a censor of the title - as often these are used by others.
			censorText($row['title'], false);
			
			$start_date = sscanf($row['start_date'], '%04d-%02d-%02d');
			$start_date = max(mktime(0, 0, 0, $start_date[1], $start_date[2], $start_date[0]), $low_date_time);
			$end_date = sscanf($row['end_date'], '%04d-%02d-%02d');
			$end_date = min(mktime(0, 0, 0, $end_date[1], $end_date[2], $end_date[0]), $high_date_time);

			// If we're using permissions (calendar pages?) then just output normal contextual style information.
			$allevents[] = array(
				'link' => $row['id_board'] == 0 ? $row['title'] : '<a href="' . $scripturl . '?topic=' . $row['id_topic'] . '.0">' . $row['title'] . '</a>',
				'start_date' => $row['start_date'],
				'end_date' => $row['end_date'],
			);
		}
		$smcFunc['db_free_result']($result);
	}

	// Send out the newsletter if we have anything to send!
	if (!empty($latest_news) OR !empty($posts) OR !empty($events) OR !empty($modSettings['newsltr_stats']) OR !empty($videos) OR !empty($pictures))
	{
		// if the currently loaded language isn't suported by this mod then we will need to revert to english
		if (!isset($txt['newsubscribe_mod_title'])) 
		{
			require_once($sourcedir . '/Subs-Post.php');
			loadLanguage('Modifications', 'english');
		}
		
		// construct the html message content first
		$html = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        
        <!-- Facebook sharing information tags -->
        <meta property="og:title" content="' . sprintf($txt['newsltr_email_header'], $context['forum_name']) . '" />
        <title>' . sprintf($txt['newsltr_email_header'], $context['forum_name']) . '</title>
	</head>
	<body>
		<style>' . un_htmlspecialchars($txt['newsltr_email_style']) . '</style>' .
		'<div id="content">
			<div id="header">
				<a href="' . $boardurl . '" >' . (empty($settings['header_logo_url']) ? $smcFunc['htmlspecialchars']($mbname) : '<img src="' . $smcFunc['htmlspecialchars']($settings['header_logo_url']) . '" alt="' . $smcFunc['htmlspecialchars']($mbname) . '" />') . '
				</div>
			</a>';

		if (!empty($latest_news))
			$html .=  '
			<table>
				<thead><tr><td colspan="3"><h2>' . $txt['newsltr_email_news'] . '</h2></td></tr></thead>
				<tbody><tr><td class="subject">' . $latest_news . '</td></tr></tbody>
			</table>
			';
			
		if (!empty($modSettings['newsltr_stats']))
			$html .= '
			<table>
				<thead><tr><td><h2>' . $txt['forum_stats'] . '</h2></td></tr></thead>
				<tbody>
					<tr>
						<td class="subject">
							<p>' . comma_format($modSettings['totalMessages']) .  ' ' .  $txt['posts_made'] . ' ' . $txt['in'] . ' ' . comma_format($modSettings['totalTopics']) . ' ' . $txt['topics'] . ' ' . $txt['by'] . ' ' . comma_format($modSettings['totalMembers']) . ' ' . $txt['members'] . '.
							</p>
						</td>
					</tr>
				</tbody>
			</table>
			';

		if (!empty($posts))
		{
			$html .= '
			<table>
				<thead><tr><td colspan="4"><h2>' . $txt['newsltr_email_posts'] . '</h2></td></tr></thead>
				<tbody>';
			foreach ($posts as $post)
			{
				if (empty($modSettings['messageIconChecks_disable']) && !isset($icon_sources[$post['icon']]))
					$icon_sources[$post['icon']] = file_exists($settings['theme_dir'] . '/images/post/' . $post['icon'] . '.gif') ? 'images_url' : 'default_images_url';
				$html .= '
					<tr>
						<td class="icon"><img src="' . $settings[$icon_sources[$post['icon']]] . '/post/' . $post['icon'] . '.gif' . '" /></td>
						<td class="subject"><a href="' . $scripturl . '?topic=' . $post['id_topic'] . '.0">' . censorText($post['subject']) . '</a></td>
						<td class="icon"> ' . $post['poster_name'] . '</td>
						<td class="date smalltext">' . strftime('%b %#d %I:%M:%S %p', $post['poster_time']) . '</td>
					</tr>';
			}
			$html .= '
				</tbody>
			</table>
			';
		}

		if (!empty($allevents))
		{
			$html .= '
			<table>
				<thead><tr><td colspan="2"><h2>' . $txt['newsltr_email_events'] . '</h2></td></tr></thead>
				<tbody>';
			foreach ($allevents as $event)
				$html .= '
					<tr><td  class="date smalltext">' . date("d M Y", strtotime($event['start_date'])) . ($event['start_date']==$event['end_date'] ? '' : (' - ' . date("d M Y", strtotime($event['end_date'])))) . '</td><td class="subject">' . $event['link'] . '</td></tr>';
			$html .= '
				</tbody>
			</table>
			';
		}
		
		if (!empty($videos))
		{
			$html .= '
			<table>
				<thead><tr><td colspan="2"><h2>' . $txt['newsltr_email_videos'] . '</h2></td></tr></thead>
				<tbody>';
			foreach ($videos as $v)
			{
				$html .= '
				<tr>
					<td class="subject">
						<a href="http://www.youtube.com/v/' . $v['yid'] . '&amp;rel=0&amp;autoplay=1&amp;autohide=1&amp;showinfo=1">' . $v['subject'] . '</a>
					</td>
					<td class="video">
						<a title="Play: ' . $v['subject'] . '" href="http://www.youtube.com/v/' . $v['yid'] . '&amp;rel=0&amp;autoplay=1&amp;autohide=1&amp;showinfo=1">
						<img class="vimage" src="http://i.ytimg.com/vi/' . $v['yid'] . '/default.jpg" alt="' . $v['subject'] . '"/>
						</a>
					</td>
				</tr>';
			}
			$html .= '
				</tbody>
			</table>';
		}
		
		if (!empty($pictures))
		{
			$html .= '
			<table>
				<thead><tr><td colspan="4"><h2>' . $txt['newsltr_email_pictures'] . '</h2></td></tr></thead>
				<tbody>';	
			foreach ($pictures as $picture)
				$html .= '
				<tr>
					<td class="picture">
						<a href="' . $modSettings['gallery_url'] . $picture['filename'] . '" title="' . $picture['title'] . '" >
							<img class="pimage" style="width:' . ($modSettings['gallery_thumb_width']+6) . 'px;height:' . ($modSettings['gallery_thumb_height'] + 10) . 'px;" src="' . $modSettings['gallery_url'] . $picture['thumbfilename'] . '" alt="' . $picture['title'] . '" />
						</a>
					</td>	
					<td class="subject">
						<a href="' . $modSettings['gallery_url'] . $picture['filename'] . '" title="' . $picture['title'] . '" >
							<strong>' . $picture['title'] . '</strong>
						</a>
						<span class="smalltext">' . '<br / >' . $picture['descr'] . '</span>
					</td>
					<td class="icon">
						<a href="' . $scripturl . '?action=gallery;cat=' . $picture['id_cat'] . '">' . $picture['cat_title'] . '</a> 
				</tr>';
			$html .= '
				</tbody>
			</table>';
		}
		
		$html .= '
		</div>
	</body>
</html>';
	}

	if (isset($_REQUEST['preview']))
	{
		ob_end_clean();
		echo $html; // show as a preview
		exit; // direct exit (not back to SMF!)
	}
	else
		return $html;
}

// send email news
function SendNews()
{
	global $modSettings, $settings, $sourcedir, $scripturl, $boardurl, $mbname, $txt, $smcFunc, $context;
	
	// check if should be sending any at all?
	loadEssentialThemeData(); // we need the theme logo URL!
	$html = get_news(); // fetch newsletter content
	if (empty($html)) 
		return true;  //nowt to do!

	// get list of users to send newsletter to...
	$result = $smcFunc['db_query']('', '
		SELECT email, next_ltr_date, period
			FROM {db_prefix}hcb_newsletter
		WHERE next_ltr_date < {int:time}',
		array ('time'=> time(),)
		);
	while ($row = $smcFunc['db_fetch_assoc']($result))
		$news_users[] = $row['email']; // only need email addresses
	
	$smcFunc['db_free_result']($result);

	if (!empty($news_users))
	{
		require_once($sourcedir . '/Subs-Post.php');
		
		// if the currently loaded language isn't suported by this mod then we will need to revert to english
		if (!isset($txt['newsubscribe_mod_title'])) 
			loadLanguage('Modifications', 'english');

		// Send the actual email.
		$subject = sprintf($txt['newsltr_email_header'], $context['forum_name']);
		// each message has a different unsubscribe link!
		foreach ($news_users as $user)
			sendmail($user, $subject, $html . sprintf($txt['newsltr_email_unsub'], $user), null, null, true);
		// Try to stop a timeout, this would be bad...
		@set_time_limit(300);
		if (function_exists('apache_reset_timeout'))
			@apache_reset_timeout();

		// update the next_ltr_date times for all the users we sent news to...
		$result = $smcFunc['db_query']('', '
			UPDATE {db_prefix}hcb_newsletter
				SET next_ltr_date = {int:now} + (period *86400)
			WHERE email IN({array_string:emails})',
			array ('emails'=> $news_users, 'now'=>time(),)
		);	

		// Flush the mail queue, just in case.
		AddMailQueue(true);
	}	
	return true;
}
?>
