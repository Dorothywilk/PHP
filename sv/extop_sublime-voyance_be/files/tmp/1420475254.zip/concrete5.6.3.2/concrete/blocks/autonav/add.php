<?php defined('C5_EXECUTE') or die("Access Denied."); ?>

<?php 
$info = array();
$bt->inc('form_setup_html.php', array('info' => $info, 'c' => $c)); 
?>