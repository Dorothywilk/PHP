<?php
defined('C5_EXECUTE') or die("Access Denied.");
class DashboardComposerController extends Concrete5_Controller_Dashboard_Composer {
}