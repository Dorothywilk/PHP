<?php
defined('C5_EXECUTE') or die("Access Denied.");

class DashboardSystemOptimizationClearCacheController extends Concrete5_Controller_Dashboard_System_Optimization_ClearCache {
}