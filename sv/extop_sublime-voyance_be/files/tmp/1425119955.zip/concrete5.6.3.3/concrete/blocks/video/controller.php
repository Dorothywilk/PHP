<?php

	defined('C5_EXECUTE') or die("Access Denied.");
	class VideoBlockController extends Concrete5_Controller_Block_Video {
 
	}
