<?php
defined('C5_EXECUTE') or die("Access Denied.");

class DashboardSystemMailMethodController extends Concrete5_Controller_Dashboard_System_Mail_Method {
}