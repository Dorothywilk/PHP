<?php
defined('C5_EXECUTE') or die("Access Denied.");

class DashboardSystemEnvironmentProxyController extends Concrete5_Controller_Dashboard_System_Environment_Proxy {
}
