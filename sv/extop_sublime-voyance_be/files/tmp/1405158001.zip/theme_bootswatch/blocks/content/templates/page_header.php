<?php  
	defined('C5_EXECUTE') or die("Access Denied.");
	$content = $controller->getContent();
?>
    <div class="page-header">
        <?php 	print $content; ?>
    </div>
