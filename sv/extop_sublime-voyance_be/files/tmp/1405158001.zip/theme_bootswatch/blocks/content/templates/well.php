<?php  
	defined('C5_EXECUTE') or die("Access Denied.");
	$content = $controller->getContent();
?>
    <div class="well"><?php 	print $content; ?></div>
