<?php  
	defined('C5_EXECUTE') or die("Access Denied.");
?>
    <div class="well well-large HTMLBlock"><?php  echo $content; ?></div>
