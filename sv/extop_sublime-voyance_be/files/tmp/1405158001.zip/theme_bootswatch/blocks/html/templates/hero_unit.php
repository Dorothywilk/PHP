<?php  
	defined('C5_EXECUTE') or die("Access Denied.");
?>
    <div class="hero-unit HTMLBlock">
        <?php  echo $content; ?>
    </div>
