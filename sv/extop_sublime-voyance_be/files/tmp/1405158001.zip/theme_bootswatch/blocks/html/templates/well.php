<?php  
	defined('C5_EXECUTE') or die("Access Denied.");
?>
    <div class="well HTMLBlock"><?php  echo $content; ?></div>
