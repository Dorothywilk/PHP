<?php  
	defined('C5_EXECUTE') or die("Access Denied.");
?>
    <div class="well HTMLBlock">
        <button type="button" class="close" data-dismiss="alert">&times;</button>
        <?php  echo $content; ?>
    </div>
