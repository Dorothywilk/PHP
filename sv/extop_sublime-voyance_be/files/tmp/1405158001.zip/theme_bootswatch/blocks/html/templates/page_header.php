<?php  
	defined('C5_EXECUTE') or die("Access Denied.");
?>
    <div class="page-header HTMLBlock">
        <?php  echo $content; ?>
    </div>
